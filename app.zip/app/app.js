'use strict';

angular.module('shootProofExercise', []);
